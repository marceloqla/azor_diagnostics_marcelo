// Logo image page reload
document.getElementById('logoimage').setAttribute("onclick", "window.location.href=window.location.href");
document.getElementById('show_toggle_btn').setAttribute("onclick", "toggleFloat()");
