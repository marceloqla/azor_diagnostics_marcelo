document.getElementById('divt1').setAttribute("onclick", "showTree()");
document.getElementById('divt2').setAttribute("onclick", "showHistTree()");
document.getElementById('dive2').setAttribute("onclick", "showEagle()");
document.getElementById('divex3').setAttribute("onclick", "showExams()");
