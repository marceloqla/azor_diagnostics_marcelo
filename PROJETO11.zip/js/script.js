// var $foo = $('.foo');
//
// $foo
//   .addClass('block')
//   .outerWidth(); // Reflow
//
// $foo
//   .addClass('fade-in')
//   .one(transitionEnd, function() {
//     alert('Animated');
//   });
